Vuulgaris V1 -- JLCPCB fab package
Generated 2026-09-20 from hardware/kicad/vuulgaris.kicad_pcb (f06fc5d)

*** DO NOT ORDER YET -- 2 KNOWN BOARD DEFECTS, see docs/review-packet.md ***

  1. SW4-SW9, all six buttons are shorted to ground. The TS1103S joins its
     pins 1-2 internally and 3-4 internally; we wired BTN to 1+3 and GND to
     2+4, so each terminal carries both nets. Every button reads permanently
     pressed. Fix is a reroute, not a part change.

  2. RV1-RV6 are 10k and the design needs 100k. C380211 / RK09L1240A12 is a
     10k dual-gang. At 10k the TIME knob's sweep collapses. Needs a 100k
     dual-gang JLC stocks.

  Unresolved, needs a meter rather than a decision:

  3. J7-J10, the 1/4" jacks. Neither manufacturer drawing labels the contacts.
     If pad 3 is the tip rather than the ring, a mono plug shorts every output
     to ground. Beep out one physical jack first.

  This file is generated. When those are fixed, delete this block from
  tools/mkfab.py and regenerate.

WHAT TO UPLOAD WHERE
--------------------
  vuulgaris-gerbers.zip          -> PCB tab, "Add gerber file"
  assembly/vuulgaris-BOM-jlc.csv -> Assembly, BOM file
  assembly/vuulgaris-CPL-jlc.csv -> Assembly, CPL / pick-and-place file

Upload the gerber zip AS-IS. Do not unzip and re-zip it: it is already in the
flat layout JLC expects, 13 gerbers plus 2 Excellon drill files.

BOARD
-----
  284.30 x 123.81 mm overall envelope -- NOT a rectangle, the top edge steps out at the USB-C; JLC quotes on the envelope, 4 layer (F.Cu / In1.Cu / In2.Cu = GND plane / B.Cu)
  310 placements
  Absolute origin throughout -- gerbers, drills and CPL share it.

BEFORE YOU ORDER
----------------
1. U7, DKM10E-12 (C6934792) -- JLC has ZERO stock, pre-order only at $15.10.
   This is the +/-12V converter the whole board runs on. Source it from
   Mouser / Digi-Key / Arrow and hand-fit. Through-hole 1"x1" module.

2. DS1, HS242L01W4S01 (C5139768) -- not in JLC's assembly library at all.
   Buy from LCSC (~$12.22) and fit by hand.

3. These BOM lines have no source anywhere. All through-hole, all hand-solder:
     U1                        ES_DAISY_PATCH_SM_REV1
     SW1,SW2                   SW_DPDT_FLAT
     U101,U201                 V3205SD
     VT301,VT302,VT401,VT402   VTL5C3

4. J7-J10 (PJ-603, C41409498) had 64 in stock on 2026-09-11 -- 16 boards'
   worth. The only line thin enough to cap a run.

NOTES
-----
The CPL carries rotation corrections. Bottom-side parts are sent as
180 - angle, because KiCad's flip mirrors about X while JLC reads a bottom
rotation mirrored about Y; the four SOIC-14s carry a further -90 because their
footprint is KiCad-library rather than LCSC. Do not "fix" these by hand.
