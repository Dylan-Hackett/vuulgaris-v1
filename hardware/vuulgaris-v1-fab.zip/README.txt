Vuulgaris V1 -- JLCPCB fab package
Generated 2026-09-23 from hardware/kicad/vuulgaris.kicad_pcb (67ab00b)

No known board defects as of 2026-09-22 -- docs/review-packet.md.

  (SW4-SW9, the six shorted buttons, were fixed 2026-09-22.)
  (RV1-RV6, 10k where the design needs 100k, came off the JLC BOM
   2026-09-22 -- hand-fit Alpha pots, see BEFORE YOU ORDER.)
  (J7-J10, the 1/4" jack pinout, was settled from the drawing and LCSC's
   symbol rather than a meter, since there is no jack to meter before the
   order. Beep one on the first assembled board before patching into it.)

WHAT TO UPLOAD WHERE
--------------------
  vuulgaris-gerbers.zip          -> PCB tab, "Add gerber file"
  assembly/vuulgaris-BOM-jlc.csv -> Assembly, BOM file
  assembly/vuulgaris-CPL-jlc.csv -> Assembly, CPL / pick-and-place file

Upload the gerber zip AS-IS. Do not unzip and re-zip it: it is already in the
flat layout JLC expects, 13 gerbers plus 2 Excellon drill files.

BOARD
-----
  284.30 x 125.81 mm overall envelope -- NOT a rectangle, the top edge steps out at the USB-C; JLC quotes on the envelope, 4 layer (F.Cu / In1.Cu / In2.Cu = GND plane / B.Cu)
  310 placements
  Absolute origin throughout -- gerbers, drills and CPL share it.

BEFORE YOU ORDER
----------------
1. U7, DKM10E-12 (C6934792) -- JLC has ZERO stock, pre-order only at $15.10.
   This is the +/-12V converter the whole board runs on. Source it from
   Mouser / Digi-Key / Arrow and hand-fit. Through-hole 1"x1" module.

2. DS1, HS242L01W4S01 (C5139768) -- not in JLC's assembly library at all.
   Buy from LCSC (~$12.22) and fit by hand.

3. RV1-RV6 -- the BOM line is deliberately blank, so JLC places nothing.
   Buy from Tayda and hand-fit:
     5x Alpha RD902F-40-15R1-B100K  (Tayda A-5440)  RV1-RV4, RV6
     1x Alpha RD902F-40-15R1-B10K   (Tayda A-6433)  RV5 FEEDBACK
   Do not let JLC "helpfully" match the line to C380211 -- that is the 10k
   ALPS these replace, and it fits the same holes.

4. These BOM lines have no source anywhere. All through-hole, all hand-solder:
     U1                        ES_DAISY_PATCH_SM_REV1
     SW1,SW2                   SW_DPDT_FLAT
     U101,U201                 V3205SD
     VT301,VT302,VT401,VT402   VTL5C3

5. J7-J10 (PJ-603, C41409498) had 64 in stock on 2026-09-11 -- 16 boards'
   worth. The only line thin enough to cap a run.

NOTES
-----
The CPL carries rotation corrections. Bottom-side parts are sent as
180 - angle, because KiCad's flip mirrors about X while JLC reads a bottom
rotation mirrored about Y; the four SOIC-14s carry a further -90 because their
footprint is KiCad-library rather than LCSC. Do not "fix" these by hand.
