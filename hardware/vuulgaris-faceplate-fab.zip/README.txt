Vuulgaris V1 faceplate -- JLCPCB fab package
Generated 2026-09-29 from hardware/faceplate/vuulgaris-faceplate.kicad_pcb (a3afdaa)

WHAT TO UPLOAD WHERE
--------------------
  vuulgaris-faceplate-gerbers.zip          -> PCB tab, "Add gerber file"
  assembly/vuulgaris-faceplate-BOM-jlc.csv -> Assembly, BOM file
  assembly/vuulgaris-faceplate-CPL-jlc.csv -> Assembly, CPL / pick-and-place file

Upload the gerber zip AS-IS: 11 gerbers, 2 drill files and their 2 maps, flat.

BOARD AND ORDER OPTIONS -- the front of this board is the instrument's front panel
------------------------------------------------------------------------------------
  298.29 x 137.81 mm, r6 corners, 4 layers, 1.6mm
  Solder mask BLACK, silkscreen WHITE, surface finish ENIG.
  Via covering: PLUGGED (JLC's default on 4 layers; it offers no tented there).
    NOT "Epoxy Filled & Capped": that caps the scrub pads' 763 vias, which are
    meant to stay open. Plugged fills only vias under mask.
  Mark on PCB: REMOVE MARK. An order number printed on the front lands on the
    gold face.
  Assembly: BOTTOM SIDE ONLY. Every part is on the back; the top is the face.
  44 placements.

THE FRONT IS EXPOSED GOLD ON PURPOSE (docs/decisions/0013)
----------------------------------------------------------
  F.Mask opens the whole face but the black markings, the 2mm frames round the
  pads and the via patch; each pad's openings are exactly its copper. The face
  copper is ground. If JLC's engineering review asks about large exposed copper
  or unusual mask openings, confirm: as designed.
  F.Paste is empty: no paste on the scrub pads.

BEFORE YOU ORDER
----------------
1. U1, MSP430FR2675TPTR (C2052972): JLC had 10 in stock on 2026-09-29, so a
   10-board run takes every one. Drop-in if short: MSP430FR2676TPTR (C2053559)
   or MSP430FR2676TPT (C1338445, pre-order): same PT package and pinout, twice
   the memory.
2. U1 arrives blank. JLC does not program it: the Daisy flashes it over the
   ribbon (ADR 0005), or the CAPTIVATE-PGMR through J1.

NOTES
-----
The CPL carries rotation corrections: every part is on the bottom and is sent
as 180 - angle, because KiCad's flip mirrors about X while JLC reads a bottom
rotation mirrored about Y. Every footprint here was checked against JLC's own
footprint for its part (2026-09-29) and shares its frame, so nothing further.
Do not "fix" these by hand.
TP1-TP6 (bare test pads) and E1-E4 (the scrub pads) are copper, not parts:
they are in neither the BOM nor the CPL.
